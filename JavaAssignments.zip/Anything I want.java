/*
 * Unit 1 Lesson 1 - Output in Java
 */

import java.io.*;
import static java.lang.System.*;

import java.util.Scanner;

class HelloWorld{
ArrayList<String> stuff = new ArrayList<String>();
stuff.add("Z");
stuff.add("f");
stuff.add(2, "W");
stuff.remove(1);
stuff.add("x");
System.out.println (stuff);

  }   
}



