/*
 * First For Loop
 *
 * Use a for loop to print the even numbers between 1 and 50. 
 * Print each number on a new line.
 */ 

import java.io.*;
import java.util.Scanner;

class FirstForLoopFawole {
    public static void main(String[] args)
     {
     
      //since even numbers go by 2 I just added 2 to var e and printed it
      for(int e = 2;e < 50; e+=2){
      System.out.println(e);
      
      }
}
}