/*
 * Unit 1 Lesson 1 - Output in Java
 */

import java.io.*;
import static java.lang.System.*;

import java.util.Scanner;

class fawoleHelloWorld{


     public static void main (String str[]) throws IOException {
    
         //prints in hello world
         System.out.println("Hello World");
         

     }

}
